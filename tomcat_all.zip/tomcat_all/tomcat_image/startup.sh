#!/bin/sh

# start the tomcat
$CATALINA_HOME/bin/catalina.sh run
